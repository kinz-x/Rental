import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { googleSheets } from "@/services/googleSheets";
import { toast } from "sonner";

type SheetName = "Properties" | "Tenants" | "Payments" | "Maintenance" | "Documents";

export function useSheetData(sheet: SheetName) {
  return useQuery({
    queryKey: ["googleSheets", sheet],
    queryFn: () => googleSheets.read(sheet),
    retry: 1,
    staleTime: 30_000,
  });
}

export function useSheetCreate(sheet: SheetName) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: Record<string, unknown>) => googleSheets.create(sheet, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["googleSheets", sheet] });
      toast.success(`${sheet.slice(0, -1)} created successfully`);
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useSheetUpdate(sheet: SheetName) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: Record<string, unknown>) => googleSheets.update(sheet, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["googleSheets", sheet] });
      toast.success(`${sheet.slice(0, -1)} updated successfully`);
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useSheetDelete(sheet: SheetName) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string | number) => googleSheets.delete(sheet, id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["googleSheets", sheet] });
      toast.success(`${sheet.slice(0, -1)} deleted successfully`);
    },
    onError: (e: Error) => toast.error(e.message),
  });
}
