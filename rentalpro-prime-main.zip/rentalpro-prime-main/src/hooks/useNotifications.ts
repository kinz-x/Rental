import { useMemo } from "react";
import { useSheetData } from "./useGoogleSheets";
import { differenceInDays, parse, isValid } from "date-fns";

export interface Notification {
  id: string;
  text: string;
  type: "lease" | "payment" | "maintenance";
  date?: string;
}

function tryParseDate(val: any): Date | null {
  if (!val) return null;
  const d = new Date(val);
  if (isValid(d)) return d;
  // Try common formats
  for (const fmt of ["MM/dd/yyyy", "yyyy-MM-dd", "M/d/yyyy"]) {
    try {
      const p = parse(String(val), fmt, new Date());
      if (isValid(p)) return p;
    } catch {}
  }
  return null;
}

export function useNotifications() {
  const { data: tenants = [] } = useSheetData("Tenants");
  const { data: payments = [] } = useSheetData("Payments");
  const { data: maintenance = [] } = useSheetData("Maintenance");

  const notifications = useMemo<Notification[]>(() => {
    const items: Notification[] = [];
    const now = new Date();

    // Lease expirations within 30 days
    tenants.forEach((t: any) => {
      const end = tryParseDate(t.leaseEnd || t.lease_end || t.endDate);
      if (end) {
        const days = differenceInDays(end, now);
        if (days >= 0 && days <= 30) {
          items.push({
            id: `lease-${t.id}`,
            text: `Lease for ${t.name || "tenant"} (${t.unit || t.property || ""}) expires in ${days} day${days !== 1 ? "s" : ""}`,
            type: "lease",
            date: end.toISOString(),
          });
        }
      }
    });

    // Overdue / late payments
    payments.forEach((p: any) => {
      const status = (p.status || "").toLowerCase();
      if (status === "overdue" || status === "late" || status === "pending") {
        const dueDate = tryParseDate(p.dueDate || p.due_date || p.date);
        if (dueDate && dueDate < now && status !== "completed") {
          items.push({
            id: `pay-${p.id}`,
            text: `Overdue payment of ${p.amount || ""} from ${p.tenant || "tenant"}`,
            type: "payment",
            date: dueDate.toISOString(),
          });
        }
      }
    });

    // Open / new maintenance requests
    maintenance.forEach((m: any) => {
      const status = (m.status || "").toLowerCase();
      if (status === "open" || status === "new" || status === "in progress") {
        items.push({
          id: `maint-${m.id}`,
          text: `${status === "open" || status === "new" ? "New" : "Ongoing"} maintenance: ${m.issue || m.description || m.title || "request"} at ${m.property || m.unit || ""}`,
          type: "maintenance",
        });
      }
    });

    return items.slice(0, 20);
  }, [tenants, payments, maintenance]);

  return notifications;
}
