import { Bell, Plus, UserPlus, CreditCard, Search, Settings, User, Building2, Users, DollarSign, Wrench } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SidebarTrigger } from "@/components/ui/sidebar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { useNavigate } from "react-router-dom";
import { useState, useEffect, useRef, useMemo } from "react";
import { useNotifications } from "@/hooks/useNotifications";
import { useSheetData } from "@/hooks/useGoogleSheets";

interface DashboardHeaderProps {
  onAddTenant?: () => void;
  onAddPayment?: () => void;
}

interface SearchResult {
  label: string;
  sub: string;
  category: "Properties" | "Tenants" | "Payments" | "Maintenance";
  route: string;
}

const categoryIcons = {
  Properties: Building2,
  Tenants: Users,
  Payments: DollarSign,
  Maintenance: Wrench,
};

export function DashboardHeader({ onAddTenant, onAddPayment }: DashboardHeaderProps) {
  const navigate = useNavigate();
  const [profile, setProfile] = useState({ name: "John Doe", email: "john@example.com" });
  const liveNotifications = useNotifications();
  const [readIds, setReadIds] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState("");
  const [showResults, setShowResults] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  const { data: properties = [] } = useSheetData("Properties");
  const { data: tenants = [] } = useSheetData("Tenants");
  const { data: payments = [] } = useSheetData("Payments");
  const { data: maintenance = [] } = useSheetData("Maintenance");

  useEffect(() => {
    const saved = localStorage.getItem("settings_profile");
    if (saved) {
      const parsed = JSON.parse(saved);
      setProfile({ name: `${parsed.firstName} ${parsed.lastName}`, email: parsed.email });
    }
  }, []);

  // Close search results on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setShowResults(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const searchResults = useMemo<SearchResult[]>(() => {
    const q = search.toLowerCase().trim();
    if (!q) return [];
    const results: SearchResult[] = [];

    properties.forEach((p: any) => {
      const match = [p.name, p.address, p.type, p.status].some((v) => String(v || "").toLowerCase().includes(q));
      if (match) results.push({ label: p.name, sub: `${p.address || ""} · ${p.units || 0} units`, category: "Properties", route: "/properties" });
    });

    tenants.forEach((t: any) => {
      const match = [t.name, t.email, t.phone, t.unit, t.property].some((v) => String(v || "").toLowerCase().includes(q));
      if (match) results.push({ label: t.name, sub: `${t.unit || ""} · ${t.property || ""}`, category: "Tenants", route: "/tenants" });
    });

    payments.forEach((p: any) => {
      const match = [p.tenant, p.amount, p.method, p.status].some((v) => String(v || "").toLowerCase().includes(q));
      if (match) results.push({ label: `${p.tenant} — ${p.amount}`, sub: `${p.date || ""} · ${p.status || ""}`, category: "Payments", route: "/payments" });
    });

    maintenance.forEach((m: any) => {
      const match = [m.title, m.tenant, m.unit, m.property, m.priority, m.status].some((v) => String(v || "").toLowerCase().includes(q));
      if (match) results.push({ label: m.title || m.issue || "Request", sub: `${m.property || ""} · ${m.priority || ""}`, category: "Maintenance", route: "/maintenance" });
    });

    return results.slice(0, 10);
  }, [search, properties, tenants, payments, maintenance]);

  const unreadCount = liveNotifications.filter((n) => !readIds.has(n.id)).length;

  const markAllRead = () => {
    setReadIds(new Set(liveNotifications.map((n) => n.id)));
  };

  const markRead = (id: string) => {
    setReadIds((prev) => new Set(prev).add(id));
  };

  const initials = profile.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <header className="h-16 border-b border-border bg-card flex items-center justify-between px-4 md:px-6 shrink-0">
      <div className="flex items-center gap-3">
        <SidebarTrigger className="text-muted-foreground hover:text-foreground" />
        <div className="relative hidden md:block" ref={searchRef}>
          <div className="flex items-center gap-2 bg-muted rounded-lg px-3 py-2 w-64">
            <Search className="h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              value={search}
              onChange={(e) => { setSearch(e.target.value); setShowResults(true); }}
              onFocus={() => search && setShowResults(true)}
              placeholder="Search everything..."
              className="bg-transparent text-sm outline-none w-full text-foreground placeholder:text-muted-foreground"
            />
          </div>
          {showResults && search.trim() && (
            <div className="absolute top-full left-0 mt-1 w-80 bg-popover border border-border rounded-lg shadow-lg z-50 overflow-hidden">
              {searchResults.length === 0 ? (
                <div className="px-4 py-3 text-sm text-muted-foreground">No results found</div>
              ) : (
                searchResults.map((r, i) => {
                  const Icon = categoryIcons[r.category];
                  return (
                    <button
                      key={`${r.category}-${i}`}
                      className="w-full flex items-center gap-3 px-4 py-2.5 text-left hover:bg-muted transition-colors"
                      onClick={() => { navigate(r.route); setSearch(""); setShowResults(false); }}
                    >
                      <div className="h-8 w-8 rounded-md bg-primary/10 flex items-center justify-center shrink-0">
                        <Icon className="h-4 w-4 text-primary" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-foreground truncate">{r.label}</div>
                        <div className="text-xs text-muted-foreground truncate">{r.sub}</div>
                      </div>
                      <span className="ml-auto text-[10px] font-medium text-muted-foreground uppercase tracking-wider shrink-0">{r.category}</span>
                    </button>
                  );
                })
              )}
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="default" size="sm" className="gap-2">
              <Plus className="h-4 w-4" />
              <span className="hidden sm:inline">Quick Add</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => { onAddTenant ? onAddTenant() : navigate("/tenants?action=add"); }} className="gap-2 cursor-pointer">
              <UserPlus className="h-4 w-4" />
              Add Tenant
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => { onAddPayment ? onAddPayment() : navigate("/payments?action=add"); }} className="gap-2 cursor-pointer">
              <CreditCard className="h-4 w-4" />
              Add Payment
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Notifications */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-foreground">
              <Bell className="h-5 w-5" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-destructive" />
              )}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-80">
            <DropdownMenuLabel className="flex items-center justify-between">
              Notifications
              {unreadCount > 0 && (
                <button onClick={markAllRead} className="text-xs font-normal text-primary hover:underline">
                  Mark all read
                </button>
              )}
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            {liveNotifications.length === 0 ? (
              <div className="px-3 py-4 text-sm text-muted-foreground text-center">No notifications</div>
            ) : (
              liveNotifications.map((n) => (
                <DropdownMenuItem
                  key={n.id}
                  className="flex items-start gap-2 cursor-pointer py-2.5"
                  onClick={() => markRead(n.id)}
                >
                  {!readIds.has(n.id) && <span className="mt-1.5 h-2 w-2 rounded-full bg-primary shrink-0" />}
                  <span className={readIds.has(n.id) ? "text-muted-foreground" : ""}>{n.text}</span>
                </DropdownMenuItem>
              ))
            )}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* User Menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center ml-1 cursor-pointer hover:bg-primary/20 transition-colors">
              <span className="text-sm font-semibold text-primary">{initials}</span>
            </div>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>
              <div className="text-sm font-medium">{profile.name}</div>
              <div className="text-xs text-muted-foreground">{profile.email}</div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => navigate("/settings")} className="gap-2 cursor-pointer">
              <User className="h-4 w-4" />
              Profile
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate("/settings")} className="gap-2 cursor-pointer">
              <Settings className="h-4 w-4" />
              Settings
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}