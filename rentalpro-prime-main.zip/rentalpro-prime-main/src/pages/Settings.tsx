import { useState, useEffect } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FormField, FormInput, FormSelect } from "@/components/FormField";
import { User, Building2, Bell, Shield, Sheet, CheckCircle2, AlertCircle } from "lucide-react";
import { getWebAppUrl, setWebAppUrl, googleSheets } from "@/services/googleSheets";
import { toast } from "sonner";

const PROFILE_KEY = "settings_profile";
const COMPANY_KEY = "settings_company";
const NOTIF_KEY = "settings_notifications";
const PASSWORD_KEY = "settings_password";

const defaultProfile = { firstName: "Alex", lastName: "Thompson", email: "alex@rentalpro.com", phone: "(555) 123-4567" };
const defaultCompany = { name: "RentalPro LLC", address: "456 Business Ave, Suite 200", timezone: "pst" };
const defaultNotifs = { paymentReceived: true, maintenanceRequest: true, leaseExpiring: true, latePayment: true };

function loadJSON<T>(key: string, fallback: T): T {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch { return fallback; }
}

const Settings = () => {
  const [sheetUrl, setSheetUrl] = useState(getWebAppUrl());
  const [connected, setConnected] = useState(false);
  const [testing, setTesting] = useState(false);

  const [profile, setProfile] = useState(() => loadJSON(PROFILE_KEY, defaultProfile));
  const [company, setCompany] = useState(() => loadJSON(COMPANY_KEY, defaultCompany));
  const [notifs, setNotifs] = useState(() => loadJSON(NOTIF_KEY, defaultNotifs));
  const [passwords, setPasswords] = useState({ current: "", newPass: "", confirm: "" });
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingCompany, setSavingCompany] = useState(false);
  const [savingPassword, setSavingPassword] = useState(false);

  useEffect(() => { setConnected(!!getWebAppUrl()); }, []);

  const handleSaveProfile = () => {
    setSavingProfile(true);
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
    setTimeout(() => { setSavingProfile(false); toast.success("Profile saved!"); }, 300);
  };

  const handleSaveCompany = () => {
    setSavingCompany(true);
    localStorage.setItem(COMPANY_KEY, JSON.stringify(company));
    setTimeout(() => { setSavingCompany(false); toast.success("Company settings saved!"); }, 300);
  };

  const handleToggleNotif = (key: string) => {
    const updated = { ...notifs, [key]: !notifs[key as keyof typeof notifs] };
    setNotifs(updated);
    localStorage.setItem(NOTIF_KEY, JSON.stringify(updated));
    toast.success("Notification preference updated");
  };

  const handleUpdatePassword = () => {
    if (!passwords.current) { toast.error("Please enter your current password"); return; }
    if (!passwords.newPass) { toast.error("Please enter a new password"); return; }
    if (passwords.newPass.length < 6) { toast.error("Password must be at least 6 characters"); return; }
    if (passwords.newPass !== passwords.confirm) { toast.error("Passwords do not match"); return; }

    setSavingPassword(true);
    localStorage.setItem(PASSWORD_KEY, JSON.stringify({ updated: new Date().toISOString() }));
    setTimeout(() => {
      setSavingPassword(false);
      setPasswords({ current: "", newPass: "", confirm: "" });
      toast.success("Password updated successfully!");
    }, 300);
  };

  const handleSaveUrl = () => {
    setWebAppUrl(sheetUrl);
    setConnected(!!sheetUrl);
    toast.success("Google Sheets URL saved!");
  };

  const handleTest = async () => {
    setTesting(true);
    try {
      await googleSheets.read("Properties");
      toast.success("✅ Connection successful! Sheets are accessible.");
    } catch (err: any) {
      toast.error("Connection failed: " + err.message);
    } finally {
      setTesting(false);
    }
  };

  const notifItems = [
    { key: "paymentReceived", label: "Payment received", desc: "Get notified when a tenant makes a payment" },
    { key: "maintenanceRequest", label: "Maintenance request", desc: "Alert when new maintenance requests are submitted" },
    { key: "leaseExpiring", label: "Lease expiring", desc: "Reminder 30 days before lease expiration" },
    { key: "latePayment", label: "Late payment", desc: "Notify when rent payment is overdue" },
  ];

  return (
  <DashboardLayout>
    <div className="mb-6 animate-fade-in">
      <h1 className="text-2xl font-bold text-foreground tracking-tight">Settings</h1>
      <p className="text-sm text-muted-foreground mt-1">Manage your account and preferences</p>
    </div>

    <div className="space-y-6 max-w-3xl">
      {/* Profile */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-accent flex items-center justify-center"><User className="h-4 w-4 text-accent-foreground" /></div>
            <div><CardTitle className="text-base">Profile</CardTitle><CardDescription>Your personal information</CardDescription></div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormField label="First Name">
              <FormInput value={profile.firstName} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setProfile({ ...profile, firstName: e.target.value })} />
            </FormField>
            <FormField label="Last Name">
              <FormInput value={profile.lastName} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setProfile({ ...profile, lastName: e.target.value })} />
            </FormField>
          </div>
          <FormField label="Email">
            <FormInput type="email" value={profile.email} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setProfile({ ...profile, email: e.target.value })} />
          </FormField>
          <FormField label="Phone">
            <FormInput type="tel" value={profile.phone} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setProfile({ ...profile, phone: e.target.value })} />
          </FormField>
          <Button onClick={handleSaveProfile} disabled={savingProfile}>
            {savingProfile ? "Saving..." : "Save Changes"}
          </Button>
        </CardContent>
      </Card>

      {/* Company */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-accent flex items-center justify-center"><Building2 className="h-4 w-4 text-accent-foreground" /></div>
            <div><CardTitle className="text-base">Company</CardTitle><CardDescription>Organization settings</CardDescription></div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <FormField label="Company Name">
            <FormInput value={company.name} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCompany({ ...company, name: e.target.value })} />
          </FormField>
          <FormField label="Business Address">
            <FormInput value={company.address} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCompany({ ...company, address: e.target.value })} />
          </FormField>
          <FormField label="Timezone">
            <FormSelect value={company.timezone} onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setCompany({ ...company, timezone: e.target.value })}>
              <option value="est">Eastern (EST)</option>
              <option value="cst">Central (CST)</option>
              <option value="mst">Mountain (MST)</option>
              <option value="pst">Pacific (PST)</option>
            </FormSelect>
          </FormField>
          <Button onClick={handleSaveCompany} disabled={savingCompany}>
            {savingCompany ? "Saving..." : "Save Changes"}
          </Button>
        </CardContent>
      </Card>

      {/* Notifications */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-accent flex items-center justify-center"><Bell className="h-4 w-4 text-accent-foreground" /></div>
            <div><CardTitle className="text-base">Notifications</CardTitle><CardDescription>Configure alert preferences</CardDescription></div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {notifItems.map((item) => (
            <div key={item.key} className="flex items-center justify-between py-2 border-b border-border last:border-0">
              <div>
                <p className="text-sm font-medium text-foreground">{item.label}</p>
                <p className="text-xs text-muted-foreground">{item.desc}</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={notifs[item.key as keyof typeof notifs]}
                  onChange={() => handleToggleNotif(item.key)}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-muted rounded-full peer peer-checked:bg-primary transition-colors after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:after:translate-x-full" />
              </label>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Security */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-accent flex items-center justify-center"><Shield className="h-4 w-4 text-accent-foreground" /></div>
            <div><CardTitle className="text-base">Security</CardTitle><CardDescription>Password and authentication</CardDescription></div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <FormField label="Current Password">
            <FormInput type="password" placeholder="••••••••" value={passwords.current} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPasswords({ ...passwords, current: e.target.value })} />
          </FormField>
          <FormField label="New Password">
            <FormInput type="password" placeholder="••••••••" value={passwords.newPass} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPasswords({ ...passwords, newPass: e.target.value })} />
          </FormField>
          <FormField label="Confirm Password">
            <FormInput type="password" placeholder="••••••••" value={passwords.confirm} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPasswords({ ...passwords, confirm: e.target.value })} />
          </FormField>
          <Button onClick={handleUpdatePassword} disabled={savingPassword}>
            {savingPassword ? "Updating..." : "Update Password"}
          </Button>
        </CardContent>
      </Card>

      {/* Google Sheets Integration */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-accent flex items-center justify-center"><Sheet className="h-4 w-4 text-accent-foreground" /></div>
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                Google Sheets Integration
                {connected ? <CheckCircle2 className="h-4 w-4 text-success" /> : <AlertCircle className="h-4 w-4 text-muted-foreground" />}
              </CardTitle>
              <CardDescription>Connect your Google Sheet as a database</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <FormField label="Apps Script Web App URL">
            <FormInput
              placeholder="https://script.google.com/macros/s/.../exec"
              value={sheetUrl}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSheetUrl(e.target.value)}
            />
          </FormField>
          <div className="flex gap-2">
            <Button onClick={handleSaveUrl}>Save URL</Button>
            <Button variant="outline" onClick={handleTest} disabled={!sheetUrl || testing}>
              {testing ? "Testing..." : "Test Connection"}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Deploy the provided <code className="bg-muted px-1 rounded">code.gs</code> script in your Google Sheet, then paste the Web App URL here.
          </p>
        </CardContent>
      </Card>
    </div>
  </DashboardLayout>
  );
};

export default Settings;
