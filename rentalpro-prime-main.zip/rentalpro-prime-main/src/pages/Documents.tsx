import { useState, useRef } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { DataTable } from "@/components/DataTable";
import { Button } from "@/components/ui/button";
import { FormModal } from "@/components/FormModal";
import { FormField, FormInput, FormSelect } from "@/components/FormField";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { useSheetData, useSheetCreate, useSheetUpdate, useSheetDelete } from "@/hooks/useGoogleSheets";
import { googleSheets } from "@/services/googleSheets";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { FileText, Trash2, Upload, File, FileSpreadsheet, FileImage, Pencil, Eye, ExternalLink, Download } from "lucide-react";
import { toast } from "sonner";

const FileIcon = ({ type }: { type: string }) => {
  const t = type?.toLowerCase() || "";
  if (["spreadsheet", "tax", "financial"].includes(t)) return <FileSpreadsheet className="h-4 w-4 text-success" />;
  if (["image", "photos"].includes(t)) return <FileImage className="h-4 w-4 text-primary" />;
  return <File className="h-4 w-4 text-destructive" />;
};

const Documents = () => {
  const { data: documents = [], isLoading } = useSheetData("Documents");
  const { data: properties = [] } = useSheetData("Properties");
  const createMut = useSheetCreate("Documents");
  const updateMut = useSheetUpdate("Documents");
  const deleteMut = useSheetDelete("Documents");

  const [modal, setModal] = useState(false);
  const [editItem, setEditItem] = useState<any>(null);
  const [deleteItem, setDeleteItem] = useState<any>(null);
  const [viewItem, setViewItem] = useState<any>(null);
  const [uploading, setUploading] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);

  const openEdit = (item: any) => { setEditItem(item); setModal(true); };
  const closeModal = () => { setEditItem(null); setModal(false); };

  const handleSubmit = async () => {
    const form = formRef.current;
    if (!form) return;
    const fd = new FormData(form);

    if (editItem) {
      const row: Record<string, unknown> = {
        id: editItem.id,
        name: fd.get("name"),
        type: fd.get("type"),
        property: fd.get("property"),
        uploaded: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
        fileNames: editItem.fileNames || "",
        fileCount: editItem.fileCount || "1",
        fileUrls: editItem.fileUrls || "",
        viewUrls: editItem.viewUrls || "",
      };
      updateMut.mutate(row, { onSuccess: closeModal });
    } else {
      const fileInput = form.querySelector<HTMLInputElement>('input[type="file"]');
      const files = fileInput?.files;

      if (!files || files.length === 0) {
        toast.error("Please select at least one file to upload.");
        return;
      }

      setUploading(true);
      try {
        // Upload files to Google Drive
        const uploadedFiles = await googleSheets.uploadFiles(Array.from(files));
        const fileNames = uploadedFiles.map(f => f.name).join(", ");
        const fileUrls = uploadedFiles.map(f => f.url).join("|||");
        const viewUrls = uploadedFiles.map(f => f.viewUrl).join("|||");
        const fileCount = String(uploadedFiles.length);

        const row: Record<string, unknown> = {
          name: fd.get("name"),
          type: fd.get("type"),
          property: fd.get("property"),
          uploaded: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
          fileNames,
          fileCount,
          fileUrls,
          viewUrls,
        };
        createMut.mutate(row, { onSuccess: closeModal });
      } catch (err: any) {
        toast.error("File upload failed: " + err.message);
      } finally {
        setUploading(false);
      }
    }
  };

  const handleDelete = () => {
    if (deleteItem) deleteMut.mutate(deleteItem.id, { onSuccess: () => setDeleteItem(null) });
  };

  // Parse file URLs for viewing
  const getFileLinks = (item: any) => {
    const names = (item.fileNames || "").split(",").map((n: string) => n.trim()).filter(Boolean);
    const urls = (item.fileUrls || "").split("|||").filter(Boolean);
    const views = (item.viewUrls || "").split("|||").filter(Boolean);
    return names.map((name: string, i: number) => ({
      name,
      url: urls[i] || "",
      viewUrl: views[i] || "",
    }));
  };

  // Stats
  const totalDocs = documents.length;
  const leaseCount = documents.filter((d: any) => d.type?.toLowerCase() === "lease").length;
  const financialCount = documents.filter((d: any) => ["tax", "financial", "insurance"].includes(d.type?.toLowerCase())).length;
  const mediaCount = documents.filter((d: any) => ["photos", "image"].includes(d.type?.toLowerCase())).length;

  const columns = [
    {
      key: "name", header: "Document", render: (d: any) => (
        <div className="flex items-center gap-2">
          <FileIcon type={d.type} />
          <div>
            <span className="block font-medium">{d.name}</span>
            {d.fileNames && <span className="text-xs text-muted-foreground">{d.fileNames}</span>}
          </div>
        </div>
      )
    },
    { key: "type", header: "Type" },
    { key: "property", header: "Property" },
    { key: "uploaded", header: "Uploaded" },
    { key: "fileCount", header: "Files", render: (d: any) => <span>{d.fileCount || 1}</span> },
  ];

  const tableActions = (item: any) => (
    <>
      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary" onClick={() => setViewItem(item)} title="View files">
        <Eye className="h-4 w-4" />
      </Button>
      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground" onClick={() => openEdit(item)}>
        <Pencil className="h-4 w-4" />
      </Button>
      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive" onClick={() => setDeleteItem(item)}>
        <Trash2 className="h-4 w-4" />
      </Button>
    </>
  );

  // Get the first viewable URL for the preview dialog
  const viewFiles = viewItem ? getFileLinks(viewItem) : [];
  const [activePreviewIndex, setActivePreviewIndex] = useState(0);

  return (
    <DashboardLayout>
      <div className="mb-6 animate-fade-in flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Documents</h1>
          <p className="text-sm text-muted-foreground mt-1">Store and manage property documents</p>
        </div>
        <Button onClick={() => { setEditItem(null); setModal(true); }} className="gap-2"><Upload className="h-4 w-4" /> Upload Document</Button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
        <div className="bg-card rounded-xl border border-border p-4 text-center">
          <FileText className="h-6 w-6 mx-auto mb-2 text-primary" />
          <p className="text-2xl font-bold text-foreground">{totalDocs}</p>
          <p className="text-xs text-muted-foreground">Total Documents</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-4 text-center">
          <File className="h-6 w-6 mx-auto mb-2 text-destructive" />
          <p className="text-2xl font-bold text-foreground">{leaseCount}</p>
          <p className="text-xs text-muted-foreground">Leases</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-4 text-center">
          <FileSpreadsheet className="h-6 w-6 mx-auto mb-2 text-success" />
          <p className="text-2xl font-bold text-foreground">{financialCount}</p>
          <p className="text-xs text-muted-foreground">Financial</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-4 text-center">
          <FileImage className="h-6 w-6 mx-auto mb-2 text-warning" />
          <p className="text-2xl font-bold text-foreground">{mediaCount}</p>
          <p className="text-xs text-muted-foreground">Media</p>
        </div>
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">Loading documents from Google Sheets...</div>
      ) : (
        <DataTable title="All Documents" columns={columns} data={documents} actions={tableActions} searchPlaceholder="Search documents..." />
      )}

      {/* Upload / Edit Modal */}
      <FormModal open={modal} onClose={closeModal} title={editItem ? "Edit Document" : "Upload Document"} onSubmit={handleSubmit} submitLabel={uploading ? "Uploading..." : editItem ? "Save" : "Upload"}>
        <form ref={formRef} className="space-y-4">
          <FormField label="Document Name"><FormInput name="name" defaultValue={editItem?.name || ""} placeholder="e.g. Lease Agreement" /></FormField>
          <FormField label="Document Type">
            <FormSelect name="type" defaultValue={editItem?.type || ""}>
              <option value="">Select type...</option>
              <option value="Lease">Lease</option>
              <option value="Insurance">Insurance</option>
              <option value="Inspection">Inspection</option>
              <option value="Tax">Tax</option>
              <option value="Contract">Contract</option>
              <option value="Photos">Photos</option>
            </FormSelect>
          </FormField>
          <FormField label="Property">
            <FormSelect name="property" defaultValue={editItem?.property || ""}>
              <option value="">Select property...</option>
              <option value="All Properties">All Properties</option>
              {properties.map((p: any) => (
                <option key={p.id || p.name} value={p.name}>{p.name}</option>
              ))}
            </FormSelect>
          </FormField>
          {!editItem && (
            <FormField label="Files">
              <FormInput type="file" multiple />
            </FormField>
          )}
          {uploading && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <div className="h-4 w-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              Uploading files to Google Drive...
            </div>
          )}
        </form>
      </FormModal>

      {/* View Document Dialog */}
      <Dialog open={!!viewItem} onOpenChange={(open) => { if (!open) { setViewItem(null); setActivePreviewIndex(0); } }}>
        <DialogContent className="max-w-3xl max-h-[85vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              {viewItem?.name}
            </DialogTitle>
          </DialogHeader>

          {viewFiles.length > 0 ? (
            <div className="flex flex-col gap-4 flex-1 min-h-0">
              {/* File tabs if multiple files */}
              {viewFiles.length > 1 && (
                <div className="flex gap-1 flex-wrap">
                  {viewFiles.map((f: any, i: number) => (
                    <Button
                      key={i}
                      variant={activePreviewIndex === i ? "default" : "outline"}
                      size="sm"
                      onClick={() => setActivePreviewIndex(i)}
                      className="text-xs"
                    >
                      {f.name}
                    </Button>
                  ))}
                </div>
              )}

              {/* Preview iframe */}
              {viewFiles[activePreviewIndex]?.viewUrl ? (
                <div className="flex-1 min-h-[400px] rounded-lg overflow-hidden border border-border bg-muted">
                  <iframe
                    src={viewFiles[activePreviewIndex].viewUrl}
                    className="w-full h-full min-h-[400px]"
                    title={viewFiles[activePreviewIndex].name}
                    allow="autoplay"
                  />
                </div>
              ) : (
                <div className="flex-1 flex items-center justify-center text-muted-foreground py-12">
                  No preview available for this file.
                </div>
              )}

              {/* Action buttons */}
              <div className="flex gap-2 justify-end">
                {viewFiles[activePreviewIndex]?.url && (
                  <Button variant="outline" size="sm" asChild>
                    <a href={viewFiles[activePreviewIndex].url} target="_blank" rel="noopener noreferrer" className="gap-2">
                      <ExternalLink className="h-4 w-4" /> Open in Drive
                    </a>
                  </Button>
                )}
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center text-muted-foreground py-12">
              No files attached to this document. Edit the document to add files.
            </div>
          )}
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!deleteItem}
        onClose={() => setDeleteItem(null)}
        onConfirm={handleDelete}
        title="Delete Document"
        description={`Are you sure you want to delete "${deleteItem?.name}"? This action cannot be undone.`}
      />
    </DashboardLayout>
  );
};

export default Documents;
