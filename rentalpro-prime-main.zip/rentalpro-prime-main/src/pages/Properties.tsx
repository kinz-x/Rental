import { useState, useRef } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { StatCard } from "@/components/StatCard";
import { DataTable } from "@/components/DataTable";
import { FormModal } from "@/components/FormModal";
import { FormField, FormInput, FormSelect } from "@/components/FormField";
import { Button } from "@/components/ui/button";
import { Building2, Home, DollarSign, Percent, Pencil, Trash2, Plus, CheckCircle2, Clock } from "lucide-react";
import { useSheetData, useSheetCreate, useSheetUpdate, useSheetDelete } from "@/hooks/useGoogleSheets";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { toast } from "sonner";

const StatusBadge = ({ status }: { status: string }) => {
  const variants: Record<string, string> = {
    Active: "bg-success/10 text-success border-success/20",
    Maintenance: "bg-warning/10 text-warning border-warning/20",
  };
  return (
    <span className={`inline-flex items-center gap-1 text-xs font-medium px-2.5 py-0.5 rounded-full border ${variants[status] || ""}`}>
      {status === "Active" ? <CheckCircle2 className="h-3 w-3" /> : <Clock className="h-3 w-3" />}
      {status}
    </span>
  );
};

const Properties = () => {
  const { data: properties = [], isLoading } = useSheetData("Properties");
  const createMut = useSheetCreate("Properties");
  const updateMut = useSheetUpdate("Properties");
  const deleteMut = useSheetDelete("Properties");

  const [modal, setModal] = useState(false);
  const [editItem, setEditItem] = useState<any>(null);
  const [deleteItem, setDeleteItem] = useState<any>(null);
  const formRef = useRef<HTMLFormElement>(null);

  const openEdit = (item: any) => { setEditItem(item); setModal(true); };
  const closeModal = () => { setEditItem(null); setModal(false); };

  const handleSubmit = () => {
    const form = formRef.current;
    if (!form) return;
    const fd = new FormData(form);
    const row: Record<string, unknown> = {
      name: fd.get("name"),
      address: fd.get("address"),
      type: fd.get("type"),
      units: Number(fd.get("units")) || 0,
      occupied: Number(fd.get("occupied")) || 0,
      rent: fd.get("rent"),
      status: fd.get("status") || "Active",
    };
    if (editItem) {
      row.id = editItem.id;
      updateMut.mutate(row, { onSuccess: closeModal });
    } else {
      createMut.mutate(row, { onSuccess: closeModal });
    }
  };

  const handleDelete = () => {
    if (deleteItem) deleteMut.mutate(deleteItem.id, { onSuccess: () => setDeleteItem(null) });
  };

  const totalUnits = properties.reduce((s: number, p: any) => s + (Number(p.units) || 0), 0);
  const totalOccupied = properties.reduce((s: number, p: any) => s + (Number(p.occupied) || 0), 0);
  const occupancyRate = totalUnits > 0 ? Math.round((totalOccupied / totalUnits) * 100) : 0;
  const totalRev = properties.reduce((s: number, p: any) => {
    const r = String(p.rent || "0").replace(/[^0-9.]/g, "");
    return s + (Number(r) || 0);
  }, 0);

  const columns = [
    { key: "name", header: "Property Name" },
    { key: "address", header: "Address" },
    { key: "type", header: "Type" },
    { key: "units", header: "Units", render: (p: any) => <span>{p.occupied || 0}/{p.units || 0}</span> },
    { key: "rent", header: "Monthly Revenue" },
    { key: "status", header: "Status", render: (p: any) => <StatusBadge status={p.status || "Active"} /> },
  ];

  const tableActions = (item: any) => (
    <>
      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground" onClick={() => openEdit(item)}><Pencil className="h-4 w-4" /></Button>
      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive" onClick={() => setDeleteItem(item)}><Trash2 className="h-4 w-4" /></Button>
    </>
  );

  return (
    <DashboardLayout>
      <div className="mb-6 animate-fade-in flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Properties</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage your property portfolio</p>
        </div>
        <Button onClick={() => { setEditItem(null); setModal(true); }} className="gap-2"><Plus className="h-4 w-4" /> Add Property</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard title="Total Properties" value={String(properties.length)} icon={Building2} delay={0} />
        <StatCard title="Total Units" value={String(totalUnits)} icon={Home} delay={50} />
        <StatCard title="Occupancy Rate" value={`${occupancyRate}%`} icon={Percent} delay={100} />
        <StatCard title="Monthly Revenue" value={`$${totalRev.toLocaleString()}`} icon={DollarSign} delay={150} />
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">Loading properties from Google Sheets...</div>
      ) : (
        <DataTable title="All Properties" columns={columns} data={properties} actions={tableActions} searchPlaceholder="Search properties..." />
      )}

      <FormModal open={modal} onClose={closeModal} title={editItem ? "Edit Property" : "Add New Property"} onSubmit={handleSubmit}>
        <form ref={formRef} className="space-y-4">
          <FormField label="Property Name"><FormInput name="name" defaultValue={editItem?.name || ""} placeholder="e.g. Sunset Apartments" /></FormField>
          <FormField label="Address"><FormInput name="address" defaultValue={editItem?.address || ""} placeholder="123 Main St, City, State" /></FormField>
          <FormField label="Property Type">
            <FormSelect name="type" defaultValue={editItem?.type || ""}>
              <option value="">Select type...</option>
              <option value="Apartment">Apartment</option>
              <option value="Townhome">Townhome</option>
              <option value="Condo">Condo</option>
              <option value="Single Family">Single Family</option>
            </FormSelect>
          </FormField>
          <FormField label="Number of Units"><FormInput name="units" type="number" defaultValue={editItem?.units || ""} placeholder="0" /></FormField>
          <FormField label="Occupied Units"><FormInput name="occupied" type="number" defaultValue={editItem?.occupied || ""} placeholder="0" /></FormField>
          <FormField label="Monthly Rent"><FormInput name="rent" defaultValue={editItem?.rent || ""} placeholder="$0.00" /></FormField>
          <FormField label="Status">
            <FormSelect name="status" defaultValue={editItem?.status || "Active"}>
              <option value="Active">Active</option>
              <option value="Maintenance">Maintenance</option>
            </FormSelect>
          </FormField>
        </form>
      </FormModal>

      <ConfirmDialog
        open={!!deleteItem}
        onClose={() => setDeleteItem(null)}
        onConfirm={handleDelete}
        title="Delete Property"
        description={`Are you sure you want to delete "${deleteItem?.name}"? This action cannot be undone.`}
      />
    </DashboardLayout>
  );
};

export default Properties;
