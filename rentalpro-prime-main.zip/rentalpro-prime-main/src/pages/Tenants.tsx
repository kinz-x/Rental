import { useState, useRef, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { DashboardLayout } from "@/components/DashboardLayout";
import { StatCard } from "@/components/StatCard";
import { DataTable } from "@/components/DataTable";
import { FormModal } from "@/components/FormModal";
import { FormField, FormInput, FormSelect } from "@/components/FormField";
import { Button } from "@/components/ui/button";
import { Users, UserPlus, UserCheck, UserX, Pencil, Trash2, Plus, CheckCircle2, Clock, AlertCircle } from "lucide-react";
import { useSheetData, useSheetCreate, useSheetUpdate, useSheetDelete } from "@/hooks/useGoogleSheets";
import { ConfirmDialog } from "@/components/ConfirmDialog";

const StatusBadge = ({ status }: { status: string }) => {
  const variants: Record<string, string> = {
    Active: "bg-success/10 text-success border-success/20",
    Late: "bg-destructive/10 text-destructive border-destructive/20",
    Notice: "bg-warning/10 text-warning border-warning/20",
  };
  return (
    <span className={`inline-flex items-center gap-1 text-xs font-medium px-2.5 py-0.5 rounded-full border ${variants[status] || ""}`}>
      {status === "Active" ? <CheckCircle2 className="h-3 w-3" /> : status === "Late" ? <AlertCircle className="h-3 w-3" /> : <Clock className="h-3 w-3" />}
      {status}
    </span>
  );
};

const Tenants = () => {
  const { data: tenants = [], isLoading } = useSheetData("Tenants");
  const { data: properties = [] } = useSheetData("Properties");
  const createMut = useSheetCreate("Tenants");
  const updateMut = useSheetUpdate("Tenants");
  const deleteMut = useSheetDelete("Tenants");

  const [searchParams, setSearchParams] = useSearchParams();
  const [modal, setModal] = useState(false);
  const [editItem, setEditItem] = useState<any>(null);
  const [deleteItem, setDeleteItem] = useState<any>(null);
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (searchParams.get("action") === "add") {
      setEditItem(null);
      setModal(true);
      setSearchParams({}, { replace: true });
    }
  }, [searchParams, setSearchParams]);

  const openEdit = (item: any) => { setEditItem(item); setModal(true); };
  const closeModal = () => { setEditItem(null); setModal(false); };

  const handleSubmit = () => {
    const form = formRef.current;
    if (!form) return;
    const fd = new FormData(form);
    const row: Record<string, unknown> = {
      name: fd.get("name"),
      email: fd.get("email"),
      phone: fd.get("phone"),
      property: fd.get("property"),
      unit: fd.get("unit"),
      rent: fd.get("rent"),
      status: fd.get("status") || "Active",
      leaseEnd: fd.get("leaseEnd"),
    };
    if (editItem) {
      row.id = editItem.id;
      updateMut.mutate(row, { onSuccess: closeModal });
    } else {
      createMut.mutate(row, { onSuccess: closeModal });
    }
  };

  const handleDelete = () => {
    if (deleteItem) deleteMut.mutate(deleteItem.id, { onSuccess: () => setDeleteItem(null) });
  };

  const active = tenants.filter((t: any) => t.status === "Active").length;
  const notice = tenants.filter((t: any) => t.status === "Notice").length;

  const columns = [
    { key: "name", header: "Name" },
    { key: "email", header: "Email" },
    { key: "unit", header: "Unit" },
    { key: "property", header: "Property" },
    { key: "rent", header: "Rent" },
    { key: "status", header: "Status", render: (t: any) => <StatusBadge status={t.status || "Active"} /> },
    { key: "leaseEnd", header: "Lease End" },
  ];

  const tableActions = (item: any) => (
    <>
      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground" onClick={() => openEdit(item)}><Pencil className="h-4 w-4" /></Button>
      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive" onClick={() => setDeleteItem(item)}><Trash2 className="h-4 w-4" /></Button>
    </>
  );

  return (
    <DashboardLayout onAddTenant={() => { setEditItem(null); setModal(true); }}>
      <div className="mb-6 animate-fade-in flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Tenants</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage your tenants and leases</p>
        </div>
        <Button onClick={() => { setEditItem(null); setModal(true); }} className="gap-2"><Plus className="h-4 w-4" /> Add Tenant</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard title="Total Tenants" value={String(tenants.length)} icon={Users} delay={0} />
        <StatCard title="Active Leases" value={String(active)} icon={UserCheck} delay={50} />
        <StatCard title="Late" value={String(tenants.filter((t: any) => t.status === "Late").length)} icon={AlertCircle} delay={100} />
        <StatCard title="Expiring Soon" value={String(notice)} icon={UserX} delay={150} />
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">Loading tenants from Google Sheets...</div>
      ) : (
        <DataTable title="All Tenants" columns={columns} data={tenants} actions={tableActions} searchPlaceholder="Search tenants..." />
      )}

      <FormModal open={modal} onClose={closeModal} title={editItem ? "Edit Tenant" : "Add New Tenant"} onSubmit={handleSubmit}>
        <form ref={formRef} className="space-y-4">
          <FormField label="Full Name"><FormInput name="name" defaultValue={editItem?.name || ""} placeholder="e.g. John Smith" /></FormField>
          <FormField label="Email"><FormInput name="email" type="email" defaultValue={editItem?.email || ""} placeholder="john@example.com" /></FormField>
          <FormField label="Phone"><FormInput name="phone" type="tel" defaultValue={editItem?.phone || ""} placeholder="(555) 000-0000" /></FormField>
          <FormField label="Property">
            <FormSelect name="property" defaultValue={editItem?.property || ""}>
              <option value="">Select property...</option>
              {properties.map((p: any) => (
                <option key={p.id} value={p.name}>{p.name}</option>
              ))}
            </FormSelect>
          </FormField>
          <FormField label="Unit"><FormInput name="unit" defaultValue={editItem?.unit || ""} placeholder="e.g. Apt 101" /></FormField>
          <FormField label="Monthly Rent"><FormInput name="rent" defaultValue={editItem?.rent || ""} placeholder="$0.00" /></FormField>
          <FormField label="Lease End"><FormInput name="leaseEnd" type="date" defaultValue={editItem?.leaseEnd || ""} /></FormField>
          <FormField label="Status">
            <FormSelect name="status" defaultValue={editItem?.status || "Active"}>
              <option value="Active">Active</option>
              <option value="Late">Late</option>
              <option value="Notice">Notice</option>
            </FormSelect>
          </FormField>
        </form>
      </FormModal>

      <ConfirmDialog
        open={!!deleteItem}
        onClose={() => setDeleteItem(null)}
        onConfirm={handleDelete}
        title="Delete Tenant"
        description={`Are you sure you want to delete "${deleteItem?.name}"? This action cannot be undone.`}
      />
    </DashboardLayout>
  );
};

export default Tenants;
