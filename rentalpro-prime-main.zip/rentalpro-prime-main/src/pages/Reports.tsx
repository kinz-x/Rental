import { DashboardLayout } from "@/components/DashboardLayout";
import { StatCard } from "@/components/StatCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, TrendingUp, Percent, Building2 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { useSheetData } from "@/hooks/useGoogleSheets";

const COLORS = ["hsl(234, 85%, 60%)", "hsl(142, 72%, 42%)", "hsl(38, 92%, 50%)", "hsl(280, 65%, 60%)"];

const Reports = () => {
  const { data: properties = [] } = useSheetData("Properties");
  const { data: tenants = [] } = useSheetData("Tenants");
  const { data: payments = [] } = useSheetData("Payments");
  const { data: maintenance = [] } = useSheetData("Maintenance");

  const parseAmount = (v: any) => Number(String(v || "0").replace(/[^0-9.]/g, "")) || 0;

  // Revenue stats
  const completedPayments = payments.filter((p: any) => p.status === "Completed");
  const totalRevenue = completedPayments.reduce((s: number, p: any) => s + parseAmount(p.amount), 0);
  const pendingRevenue = payments.filter((p: any) => p.status !== "Completed").reduce((s: number, p: any) => s + parseAmount(p.amount), 0);

  // Occupancy
  const totalUnits = properties.reduce((s: number, p: any) => s + (Number(p.units) || 0), 0);
  const totalOccupied = properties.reduce((s: number, p: any) => s + (Number(p.occupied) || 0), 0);
  const occupancyRate = totalUnits > 0 ? Math.round((totalOccupied / totalUnits) * 100) : 0;

  // Revenue by property
  const revenueByProperty: Record<string, number> = {};
  completedPayments.forEach((p: any) => {
    const prop = p.property || "Unknown";
    revenueByProperty[prop] = (revenueByProperty[prop] || 0) + parseAmount(p.amount);
  });
  const revenueData = Object.entries(revenueByProperty).map(([name, revenue]) => ({ name, revenue }));

  // Property type breakdown
  const typeCount: Record<string, number> = {};
  properties.forEach((p: any) => {
    const t = p.type || "Other";
    typeCount[t] = (typeCount[t] || 0) + (Number(p.units) || 1);
  });
  const propertyTypeData = Object.entries(typeCount).map(([name, value]) => ({ name, value }));

  return (
    <DashboardLayout>
      <div className="mb-6 animate-fade-in">
        <h1 className="text-2xl font-bold text-foreground tracking-tight">Reports</h1>
        <p className="text-sm text-muted-foreground mt-1">Analytics and insights from your Google Sheets data</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard title="Total Revenue" value={`$${totalRevenue.toLocaleString()}`} icon={DollarSign} delay={0} />
        <StatCard title="Outstanding" value={`$${pendingRevenue.toLocaleString()}`} icon={TrendingUp} delay={50} />
        <StatCard title="Avg. Occupancy" value={`${occupancyRate}%`} icon={Percent} delay={100} />
        <StatCard title="Properties" value={String(properties.length)} icon={Building2} delay={150} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader><CardTitle className="text-base">Revenue by Property</CardTitle></CardHeader>
          <CardContent>
            {revenueData.length > 0 ? (
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={revenueData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(220, 16%, 90%)" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} stroke="hsl(220, 10%, 46%)" />
                  <YAxis tick={{ fontSize: 12 }} stroke="hsl(220, 10%, 46%)" tickFormatter={(v) => `$${v / 1000}k`} />
                  <Tooltip formatter={(v: number) => [`$${v.toLocaleString()}`, "Revenue"]} />
                  <Bar dataKey="revenue" fill="hsl(234, 85%, 60%)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[280px] flex items-center justify-center text-muted-foreground text-sm">No payment data yet</div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Portfolio Breakdown</CardTitle></CardHeader>
          <CardContent>
            {propertyTypeData.length > 0 ? (
              <div className="flex flex-col sm:flex-row items-center gap-8">
                <ResponsiveContainer width={200} height={200}>
                  <PieChart>
                    <Pie data={propertyTypeData} cx="50%" cy="50%" outerRadius={80} dataKey="value" stroke="none">
                      {propertyTypeData.map((_, index) => (
                        <Cell key={index} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
                <div className="space-y-3">
                  {propertyTypeData.map((entry, index) => (
                    <div key={entry.name} className="flex items-center gap-3">
                      <div className="h-3 w-3 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                      <span className="text-sm text-foreground">{entry.name}</span>
                      <span className="text-sm text-muted-foreground ml-auto">{entry.value} units</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="h-[200px] flex items-center justify-center text-muted-foreground text-sm">No property data yet</div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle className="text-base">Quick Stats</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between text-sm"><span className="text-muted-foreground">Total Tenants</span><span className="font-medium text-foreground">{tenants.length}</span></div>
            <div className="flex justify-between text-sm"><span className="text-muted-foreground">Active Tenants</span><span className="font-medium text-foreground">{tenants.filter((t: any) => t.status === "Active").length}</span></div>
            <div className="flex justify-between text-sm"><span className="text-muted-foreground">Total Payments</span><span className="font-medium text-foreground">{payments.length}</span></div>
            <div className="flex justify-between text-sm"><span className="text-muted-foreground">Open Maintenance</span><span className="font-medium text-foreground">{maintenance.filter((r: any) => r.status === "Open").length}</span></div>
            <div className="flex justify-between text-sm"><span className="text-muted-foreground">Total Units</span><span className="font-medium text-foreground">{totalUnits}</span></div>
            <div className="flex justify-between text-sm"><span className="text-muted-foreground">Occupied Units</span><span className="font-medium text-foreground">{totalOccupied}</span></div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Maintenance Summary</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between text-sm"><span className="text-muted-foreground">Open</span><span className="font-medium text-destructive">{maintenance.filter((r: any) => r.status === "Open").length}</span></div>
            <div className="flex justify-between text-sm"><span className="text-muted-foreground">In Progress</span><span className="font-medium text-warning">{maintenance.filter((r: any) => r.status === "In Progress").length}</span></div>
            <div className="flex justify-between text-sm"><span className="text-muted-foreground">Scheduled</span><span className="font-medium text-foreground">{maintenance.filter((r: any) => r.status === "Scheduled").length}</span></div>
            <div className="flex justify-between text-sm"><span className="text-muted-foreground">Completed</span><span className="font-medium text-success">{maintenance.filter((r: any) => r.status === "Completed").length}</span></div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default Reports;
