import { useState, useRef, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { DashboardLayout } from "@/components/DashboardLayout";
import { StatCard } from "@/components/StatCard";
import { DataTable } from "@/components/DataTable";
import { FormModal } from "@/components/FormModal";
import { FormField, FormInput, FormSelect } from "@/components/FormField";
import { Button } from "@/components/ui/button";
import { DollarSign, TrendingUp, CreditCard, AlertCircle, Pencil, Trash2, Plus, CheckCircle2, Clock } from "lucide-react";
import { useSheetData, useSheetCreate, useSheetUpdate, useSheetDelete } from "@/hooks/useGoogleSheets";
import { ConfirmDialog } from "@/components/ConfirmDialog";

const StatusBadge = ({ status }: { status: string }) => {
  const variants: Record<string, string> = {
    Completed: "bg-success/10 text-success border-success/20",
    Pending: "bg-warning/10 text-warning border-warning/20",
    Overdue: "bg-destructive/10 text-destructive border-destructive/20",
  };
  return (
    <span className={`inline-flex items-center gap-1 text-xs font-medium px-2.5 py-0.5 rounded-full border ${variants[status] || ""}`}>
      {status === "Completed" ? <CheckCircle2 className="h-3 w-3" /> : status === "Pending" ? <Clock className="h-3 w-3" /> : <AlertCircle className="h-3 w-3" />}
      {status}
    </span>
  );
};

const Payments = () => {
  const { data: payments = [], isLoading } = useSheetData("Payments");
  const { data: tenants = [] } = useSheetData("Tenants");
  const createMut = useSheetCreate("Payments");
  const updateMut = useSheetUpdate("Payments");
  const deleteMut = useSheetDelete("Payments");

  const [searchParams, setSearchParams] = useSearchParams();
  const [modal, setModal] = useState(false);
  const [editItem, setEditItem] = useState<any>(null);
  const [deleteItem, setDeleteItem] = useState<any>(null);
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (searchParams.get("action") === "add") {
      setEditItem(null);
      setModal(true);
      setSearchParams({}, { replace: true });
    }
  }, [searchParams, setSearchParams]);

  const openEdit = (item: any) => { setEditItem(item); setModal(true); };
  const closeModal = () => { setEditItem(null); setModal(false); };

  const handleSubmit = () => {
    const form = formRef.current;
    if (!form) return;
    const fd = new FormData(form);
    const row: Record<string, unknown> = {
      tenant: fd.get("tenant"),
      property: fd.get("property"),
      amount: fd.get("amount"),
      date: fd.get("date"),
      method: fd.get("method"),
      status: fd.get("status") || "Pending",
    };
    if (editItem) {
      row.id = editItem.id;
      updateMut.mutate(row, { onSuccess: closeModal });
    } else {
      createMut.mutate(row, { onSuccess: closeModal });
    }
  };

  const handleDelete = () => {
    if (deleteItem) deleteMut.mutate(deleteItem.id, { onSuccess: () => setDeleteItem(null) });
  };

  const parseAmount = (v: any) => Number(String(v || "0").replace(/[^0-9.]/g, "")) || 0;
  const completed = payments.filter((p: any) => p.status === "Completed");
  const outstanding = payments.filter((p: any) => p.status !== "Completed");
  const totalCollected = completed.reduce((s: number, p: any) => s + parseAmount(p.amount), 0);
  const totalOutstanding = outstanding.reduce((s: number, p: any) => s + parseAmount(p.amount), 0);
  const avgPayment = payments.length > 0 ? Math.round(totalCollected / (completed.length || 1)) : 0;
  const collectionRate = payments.length > 0 ? Math.round((completed.length / payments.length) * 100) : 0;

  const columns = [
    { key: "tenant", header: "Tenant" },
    { key: "property", header: "Property" },
    { key: "amount", header: "Amount" },
    { key: "date", header: "Date" },
    { key: "method", header: "Method" },
    { key: "status", header: "Status", render: (p: any) => <StatusBadge status={p.status || "Pending"} /> },
  ];

  const tableActions = (item: any) => (
    <>
      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground" onClick={() => openEdit(item)}><Pencil className="h-4 w-4" /></Button>
      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive" onClick={() => setDeleteItem(item)}><Trash2 className="h-4 w-4" /></Button>
    </>
  );

  // Build property list from tenants
  const propertyNames = [...new Set(tenants.map((t: any) => t.property).filter(Boolean))];

  return (
    <DashboardLayout onAddPayment={() => { setEditItem(null); setModal(true); }}>
      <div className="mb-6 animate-fade-in flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Payments</h1>
          <p className="text-sm text-muted-foreground mt-1">Track and manage all rent payments</p>
        </div>
        <Button onClick={() => { setEditItem(null); setModal(true); }} className="gap-2"><Plus className="h-4 w-4" /> Record Payment</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard title="Collected" value={`$${totalCollected.toLocaleString()}`} icon={DollarSign} delay={0} />
        <StatCard title="Outstanding" value={`$${totalOutstanding.toLocaleString()}`} icon={AlertCircle} delay={50} />
        <StatCard title="Collection Rate" value={`${collectionRate}%`} icon={TrendingUp} delay={100} />
        <StatCard title="Avg. Payment" value={`$${avgPayment.toLocaleString()}`} icon={CreditCard} delay={150} />
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">Loading payments from Google Sheets...</div>
      ) : (
        <DataTable title="All Payments" columns={columns} data={payments} actions={tableActions} searchPlaceholder="Search payments..." />
      )}

      <FormModal open={modal} onClose={closeModal} title={editItem ? "Edit Payment" : "Record Payment"} onSubmit={handleSubmit} submitLabel={editItem ? "Save" : "Record Payment"}>
        <form ref={formRef} className="space-y-4">
          <FormField label="Tenant">
            <FormSelect name="tenant" defaultValue={editItem?.tenant || ""}>
              <option value="">Select tenant...</option>
              {tenants.map((t: any) => (
                <option key={t.id} value={t.name}>{t.name} — {t.unit}</option>
              ))}
            </FormSelect>
          </FormField>
          <FormField label="Property">
            <FormSelect name="property" defaultValue={editItem?.property || ""}>
              <option value="">Select property...</option>
              {propertyNames.map((p: any) => (
                <option key={p} value={p}>{p}</option>
              ))}
            </FormSelect>
          </FormField>
          <FormField label="Amount"><FormInput name="amount" defaultValue={editItem?.amount || ""} placeholder="$0.00" /></FormField>
          <FormField label="Payment Method">
            <FormSelect name="method" defaultValue={editItem?.method || ""}>
              <option value="">Select method...</option>
              <option value="ACH">ACH Transfer</option>
              <option value="Credit Card">Credit Card</option>
              <option value="Check">Check</option>
              <option value="Cash">Cash</option>
            </FormSelect>
          </FormField>
          <FormField label="Date"><FormInput name="date" type="date" defaultValue={editItem?.date || ""} /></FormField>
          <FormField label="Status">
            <FormSelect name="status" defaultValue={editItem?.status || "Pending"}>
              <option value="Completed">Completed</option>
              <option value="Pending">Pending</option>
              <option value="Overdue">Overdue</option>
            </FormSelect>
          </FormField>
        </form>
      </FormModal>

      <ConfirmDialog
        open={!!deleteItem}
        onClose={() => setDeleteItem(null)}
        onConfirm={handleDelete}
        title="Delete Payment"
        description="Are you sure you want to delete this payment? This action cannot be undone."
      />
    </DashboardLayout>
  );
};

export default Payments;
