import { useState } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { StatCard } from "@/components/StatCard";
import { DataTable } from "@/components/DataTable";
import { Building2, Users, DollarSign, Wrench, CheckCircle2, Clock, AlertCircle } from "lucide-react";
import { useSheetData } from "@/hooks/useGoogleSheets";

const StatusBadge = ({ status }: { status: string }) => {
  const variants: Record<string, string> = {
    Active: "bg-success/10 text-success border-success/20",
    Completed: "bg-success/10 text-success border-success/20",
    Late: "bg-destructive/10 text-destructive border-destructive/20",
    Pending: "bg-warning/10 text-warning border-warning/20",
    Notice: "bg-warning/10 text-warning border-warning/20",
    Overdue: "bg-destructive/10 text-destructive border-destructive/20",
  };
  return (
    <span className={`inline-flex items-center gap-1 text-xs font-medium px-2.5 py-0.5 rounded-full border ${variants[status] || ""}`}>
      {(status === "Active" || status === "Completed") && <CheckCircle2 className="h-3 w-3" />}
      {(status === "Pending" || status === "Notice") && <Clock className="h-3 w-3" />}
      {(status === "Late" || status === "Overdue") && <AlertCircle className="h-3 w-3" />}
      {status}
    </span>
  );
};

const Index = () => {
  const { data: properties = [] } = useSheetData("Properties");
  const { data: tenants = [] } = useSheetData("Tenants");
  const { data: payments = [] } = useSheetData("Payments");
  const { data: maintenance = [] } = useSheetData("Maintenance");

  const activeTenants = tenants.filter((t: any) => t.status === "Active").length;
  const parseAmount = (v: any) => Number(String(v || "0").replace(/[^0-9.]/g, "")) || 0;
  const totalRevenue = payments
    .filter((p: any) => p.status === "Completed")
    .reduce((s: number, p: any) => s + parseAmount(p.amount), 0);
  const openRequests = maintenance.filter((r: any) => r.status === "Open" || r.status === "In Progress").length;

  const recentTenants = tenants.slice(0, 5);
  const recentPayments = payments.slice(0, 5);

  const tenantColumns = [
    { key: "name", header: "Name" },
    { key: "unit", header: "Unit" },
    { key: "property", header: "Property" },
    { key: "rent", header: "Rent" },
    { key: "status", header: "Status", render: (t: any) => <StatusBadge status={t.status || "Active"} /> },
  ];

  const paymentColumns = [
    { key: "tenant", header: "Tenant" },
    { key: "amount", header: "Amount" },
    { key: "date", header: "Date" },
    { key: "method", header: "Method" },
    { key: "status", header: "Status", render: (p: any) => <StatusBadge status={p.status || "Pending"} /> },
  ];

  return (
    <DashboardLayout>
      <div className="mb-6 animate-fade-in">
        <h1 className="text-2xl font-bold text-foreground tracking-tight">Dashboard</h1>
        <p className="text-sm text-muted-foreground mt-1">Welcome back! Here's your property overview.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard title="Total Properties" value={String(properties.length)} icon={Building2} delay={0} />
        <StatCard title="Active Tenants" value={String(activeTenants)} icon={Users} delay={50} />
        <StatCard title="Revenue (Collected)" value={`$${totalRevenue.toLocaleString()}`} icon={DollarSign} delay={100} />
        <StatCard title="Open Requests" value={String(openRequests)} icon={Wrench} delay={150} />
      </div>

      <div className="space-y-6">
        <DataTable title="Recent Tenants" columns={tenantColumns} data={recentTenants} searchPlaceholder="Search tenants..." />
        <DataTable title="Recent Payments" columns={paymentColumns} data={recentPayments} searchPlaceholder="Search payments..." />
      </div>
    </DashboardLayout>
  );
};

export default Index;
