import { useState, useRef } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { StatCard } from "@/components/StatCard";
import { DataTable } from "@/components/DataTable";
import { FormModal } from "@/components/FormModal";
import { FormField, FormInput, FormSelect } from "@/components/FormField";
import { Button } from "@/components/ui/button";
import { Wrench, Clock, CheckCircle2, AlertCircle, Pencil, Trash2, Plus } from "lucide-react";
import { useSheetData, useSheetCreate, useSheetUpdate, useSheetDelete } from "@/hooks/useGoogleSheets";
import { ConfirmDialog } from "@/components/ConfirmDialog";

const StatusBadge = ({ status }: { status: string }) => {
  const variants: Record<string, string> = {
    Open: "bg-destructive/10 text-destructive border-destructive/20",
    "In Progress": "bg-warning/10 text-warning border-warning/20",
    Scheduled: "bg-accent text-accent-foreground border-accent-foreground/20",
    Completed: "bg-success/10 text-success border-success/20",
  };
  return (
    <span className={`inline-flex items-center gap-1 text-xs font-medium px-2.5 py-0.5 rounded-full border ${variants[status] || ""}`}>
      {status === "Completed" ? <CheckCircle2 className="h-3 w-3" /> : status === "Open" ? <AlertCircle className="h-3 w-3" /> : <Clock className="h-3 w-3" />}
      {status}
    </span>
  );
};

const PriorityBadge = ({ priority }: { priority: string }) => {
  const variants: Record<string, string> = {
    High: "bg-destructive/10 text-destructive border-destructive/20",
    Medium: "bg-warning/10 text-warning border-warning/20",
    Low: "bg-muted text-muted-foreground border-border",
  };
  return (
    <span className={`inline-flex items-center text-xs font-medium px-2.5 py-0.5 rounded-full border ${variants[priority] || ""}`}>
      {priority}
    </span>
  );
};

const Maintenance = () => {
  const { data: requests = [], isLoading } = useSheetData("Maintenance");
  const { data: properties = [] } = useSheetData("Properties");
  const { data: tenants = [] } = useSheetData("Tenants");
  const createMut = useSheetCreate("Maintenance");
  const updateMut = useSheetUpdate("Maintenance");
  const deleteMut = useSheetDelete("Maintenance");

  const [modal, setModal] = useState(false);
  const [editItem, setEditItem] = useState<any>(null);
  const [deleteItem, setDeleteItem] = useState<any>(null);
  const formRef = useRef<HTMLFormElement>(null);

  const openEdit = (item: any) => { setEditItem(item); setModal(true); };
  const closeModal = () => { setEditItem(null); setModal(false); };

  const handleSubmit = () => {
    const form = formRef.current;
    if (!form) return;
    const fd = new FormData(form);
    const row: Record<string, unknown> = {
      title: fd.get("title"),
      description: fd.get("description"),
      tenant: fd.get("tenant"),
      property: fd.get("property"),
      unit: fd.get("unit"),
      priority: fd.get("priority"),
      status: fd.get("status") || "Open",
      created: fd.get("created") || new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
    };
    if (editItem) {
      row.id = editItem.id;
      updateMut.mutate(row, { onSuccess: closeModal });
    } else {
      createMut.mutate(row, { onSuccess: closeModal });
    }
  };

  const handleDelete = () => {
    if (deleteItem) deleteMut.mutate(deleteItem.id, { onSuccess: () => setDeleteItem(null) });
  };

  const open = requests.filter((r: any) => r.status === "Open").length;
  const inProgress = requests.filter((r: any) => r.status === "In Progress").length;
  const completed = requests.filter((r: any) => r.status === "Completed").length;

  const columns = [
    { key: "title", header: "Issue" },
    { key: "tenant", header: "Tenant" },
    { key: "unit", header: "Unit" },
    { key: "property", header: "Property" },
    { key: "priority", header: "Priority", render: (r: any) => <PriorityBadge priority={r.priority || "Low"} /> },
    { key: "status", header: "Status", render: (r: any) => <StatusBadge status={r.status || "Open"} /> },
    { key: "created", header: "Created" },
  ];

  const tableActions = (item: any) => (
    <>
      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground" onClick={() => openEdit(item)}><Pencil className="h-4 w-4" /></Button>
      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive" onClick={() => setDeleteItem(item)}><Trash2 className="h-4 w-4" /></Button>
    </>
  );

  return (
    <DashboardLayout>
      <div className="mb-6 animate-fade-in flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Maintenance</h1>
          <p className="text-sm text-muted-foreground mt-1">Track and resolve maintenance requests</p>
        </div>
        <Button onClick={() => { setEditItem(null); setModal(true); }} className="gap-2"><Plus className="h-4 w-4" /> New Request</Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard title="Open Requests" value={String(open)} icon={AlertCircle} delay={0} />
        <StatCard title="In Progress" value={String(inProgress)} icon={Wrench} delay={50} />
        <StatCard title="Completed (Total)" value={String(completed)} icon={CheckCircle2} delay={100} />
        <StatCard title="Total Requests" value={String(requests.length)} icon={Clock} delay={150} />
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">Loading maintenance requests from Google Sheets...</div>
      ) : (
        <DataTable title="All Requests" columns={columns} data={requests} actions={tableActions} searchPlaceholder="Search requests..." />
      )}

      <FormModal open={modal} onClose={closeModal} title={editItem ? "Edit Request" : "New Maintenance Request"} onSubmit={handleSubmit}>
        <form ref={formRef} className="space-y-4">
          <FormField label="Issue Title"><FormInput name="title" defaultValue={editItem?.title || ""} placeholder="e.g. Leaking faucet" /></FormField>
          <FormField label="Description"><FormInput name="description" defaultValue={editItem?.description || ""} placeholder="Describe the issue..." /></FormField>
          <FormField label="Tenant">
            <FormSelect name="tenant" defaultValue={editItem?.tenant || ""}>
              <option value="">Select tenant...</option>
              {tenants.map((t: any) => (
                <option key={t.id} value={t.name}>{t.name}</option>
              ))}
            </FormSelect>
          </FormField>
          <FormField label="Property">
            <FormSelect name="property" defaultValue={editItem?.property || ""}>
              <option value="">Select property...</option>
              {properties.map((p: any) => (
                <option key={p.id} value={p.name}>{p.name}</option>
              ))}
            </FormSelect>
          </FormField>
          <FormField label="Unit"><FormInput name="unit" defaultValue={editItem?.unit || ""} placeholder="e.g. Apt 101" /></FormField>
          <FormField label="Priority">
            <FormSelect name="priority" defaultValue={editItem?.priority || ""}>
              <option value="">Select priority...</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </FormSelect>
          </FormField>
          <FormField label="Status">
            <FormSelect name="status" defaultValue={editItem?.status || "Open"}>
              <option value="Open">Open</option>
              <option value="In Progress">In Progress</option>
              <option value="Scheduled">Scheduled</option>
              <option value="Completed">Completed</option>
            </FormSelect>
          </FormField>
        </form>
      </FormModal>

      <ConfirmDialog
        open={!!deleteItem}
        onClose={() => setDeleteItem(null)}
        onConfirm={handleDelete}
        title="Delete Request"
        description={`Are you sure you want to delete "${deleteItem?.title}"? This action cannot be undone.`}
      />
    </DashboardLayout>
  );
};

export default Maintenance;
