// Google Sheets API service via Apps Script Web App
// Set your deployed Apps Script URL in Settings or localStorage

const STORAGE_KEY = "google_sheets_webapp_url";

export function getWebAppUrl(): string {
  return localStorage.getItem(STORAGE_KEY) || "";
}

export function setWebAppUrl(url: string) {
  localStorage.setItem(STORAGE_KEY, url);
}

type SheetName = "Properties" | "Tenants" | "Payments" | "Maintenance" | "Documents";

async function request(action: string, sheet: SheetName, options?: { id?: string; body?: Record<string, unknown> }) {
  const baseUrl = getWebAppUrl();
  if (!baseUrl) throw new Error("Google Sheets Web App URL not configured. Go to Settings to set it up.");

  const url = new URL(baseUrl);
  url.searchParams.set("action", action);
  url.searchParams.set("sheet", sheet);
  if (options?.id) url.searchParams.set("id", options.id);

  const fetchOptions: RequestInit = {
    method: options?.body ? "POST" : "GET",
    redirect: "follow",
  };

  if (options?.body) {
    fetchOptions.body = JSON.stringify(options.body);
    fetchOptions.headers = { "Content-Type": "text/plain" }; // Apps Script needs text/plain for CORS
  }

  const res = await fetch(url.toString(), fetchOptions);
  const data = await res.json();

  if (data.error) throw new Error(data.error);
  return data;
}

export const googleSheets = {
  async read(sheet: SheetName) {
    const result = await request("read", sheet);
    return result.data || [];
  },

  async create(sheet: SheetName, rowData: Record<string, unknown>) {
    return request("create", sheet, { body: rowData });
  },

  async update(sheet: SheetName, rowData: Record<string, unknown>) {
    return request("update", sheet, { body: rowData });
  },

  async delete(sheet: SheetName, id: string | number) {
    return request("delete", sheet, { id: String(id) });
  },

  // Upload files to Google Drive via Apps Script
  async uploadFiles(files: File[]): Promise<{ name: string; url: string; viewUrl: string; downloadUrl: string; id: string }[]> {
    const baseUrl = getWebAppUrl();
    if (!baseUrl) throw new Error("Google Sheets Web App URL not configured.");

    const fileData = await Promise.all(
      files.map(async (file) => {
        const buffer = await file.arrayBuffer();
        const base64 = btoa(
          new Uint8Array(buffer).reduce((data, byte) => data + String.fromCharCode(byte), "")
        );
        return { name: file.name, mimeType: file.type, data: base64 };
      })
    );

    const url = new URL(baseUrl);
    url.searchParams.set("action", "uploadFiles");
    url.searchParams.set("sheet", "Documents");

    const res = await fetch(url.toString(), {
      method: "POST",
      redirect: "follow",
      body: JSON.stringify({ files: fileData, folderName: "PropertyManager_Documents" }),
      headers: { "Content-Type": "text/plain" },
    });

    const data = await res.json();
    if (data.error) throw new Error(data.error);
    return data.files || [];
  },
};
